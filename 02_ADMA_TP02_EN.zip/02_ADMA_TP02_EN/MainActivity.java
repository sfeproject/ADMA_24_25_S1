package radio.com.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    public static final int ACTION_AJOUT=1;
    private Spinner spPatient;
    private EditText edTension;
    private EditText edRythme;
    private Button btnModifier;
    private Button btnNouveau;
    private ArrayAdapter<Patient> adpPatient;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }
    private void init() {
        spPatient = (Spinner) findViewById(R.id.spPatient);
        edTension = (EditText) findViewById(R.id.edTension);
        edRythme = (EditText) findViewById(R.id.edRythme);
        btnModifier = (Button) findViewById(R.id.btnModifier);
        btnNouveau = (Button) findViewById(R.id.btnNouveau);
        adpPatient = new ArrayAdapter<Patient>(this,
                android.R.layout.simple_spinner_dropdown_item);
        spPatient.setAdapter(adpPatient);
        ajouterEcouteurs();
    }
    private void ajouterEcouteurs() {
        
    }
    
}


