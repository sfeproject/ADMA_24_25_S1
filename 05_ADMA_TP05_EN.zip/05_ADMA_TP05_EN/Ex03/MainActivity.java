package com.stat.process;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public static final int[] TAB_PRES = new int[]{R.drawable.pres00,R.drawable.pres01,R.drawable.pres02,R.drawable.pres03};
    public static final int[] TAB_LOIN = new int[]{R.drawable.loin00,R.drawable.loin01,R.drawable.loin02,R.drawable.loin03};
    private TextView tvProx;
    private ImageView imgPL;
   

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        tvProx=findViewById(R.id.tvProx);
        imgPL = findViewById(R.id.imgPL);
        ajouterEcouteur();
    }

    

}
