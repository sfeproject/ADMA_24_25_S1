package acc.com.accapp;


import android.os.Bundle;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity  {

    private TextView tvX;
    private TextView tvY;
    private TextView tvZ;
    private Button btnAjouter;
    private Button btnVider;
    private EditText edList;

   

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        tvX = (TextView) findViewById(R.id.tvX);
        tvY = (TextView) findViewById(R.id.tvY);
        tvZ = (TextView) findViewById(R.id.tvZ);
        btnAjouter = (Button) findViewById(R.id.btnAjouter);
        btnVider = (Button) findViewById(R.id.btnVider);
        edList = (EditText) findViewById(R.id.edList);


        

        ajouterEcouteurs();
    }

    private void ajouterEcouteurs() {
        btnAjouter.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                ajouter();

            }
        });
        btnVider.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                vider();

            }
        });

    }

    protected void vider() {
      

    }

    protected void ajouter() {
       


    }

    

}
