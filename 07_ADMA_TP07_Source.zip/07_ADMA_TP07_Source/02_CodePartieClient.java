//1- Déclaration des attributs
    public static final int PORT_SERVEUR = 6035;
    public static final String ADR_SERVEUR = "10.0.2.2";
    private Socket s;
    private PrintWriter pw;


//2- déclaration de ajouterEcoteur
	private void ajouterEcoteur() {
        btnConnecter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                lanceThreadClient();
            }
        });
	}
        


//3- Déclaration de  lanceThreadClient
	private void lanceThreadClient() {
        Runnable r = new Runnable() {
            @Override
            public void run() {
                demmarerClient();
            }

        };
        Thread th = new Thread(r);
        th.start();
        btnConnecter.setVisibility(View.GONE);
    }

	
//4- Déclaration de  demmarerClient
	private void demmarerClient() {
        try {
            Inet4Address i = (Inet4Address) Inet4Address.getByName(edAdresse.getText().toString());
            s = new Socket(i, Integer.parseInt(edPort.getText().toString()));
            pw = new PrintWriter(new BufferedWriter(new OutputStreamWriter(s.getOutputStream())), true);
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

//5- Déclaration de  envoyer
	private void envoyer(final String cmd) {
        Runnable r = new Runnable() {
            @Override
            public void run() {
                if (pw != null) {
                    pw.println(cmd);
                    pw.flush();
                }
            }
        };
        Thread th = new Thread(r);
        th.start();

    }

//6- envoi de la valeur des seekBars
	for (int j = 0; j < tSeek.length; j++) {
            final int finalJ = j;
            tSeek[j].setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                    envoyer(finalJ + “:” +  seekBar.getProgress());
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {

                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {

                }
            });
        }