//1- Déclaration des attributs
    private static int indice;
    private static final int PORT = 6035;
    private ServerSocket ss;
    private Socket s;
    private BufferedReader br;

//2- Lancement du thread serveur
lancerThreadServeur();

//3- Déclaration de  lancerThreadServeur
	private void lancerThreadServeur() {
        Runnable r = new Runnable() {
            @Override
            public void run() {
                demmarerServeur();
            }
        };
        Thread th = new Thread(r);
        th.start();
    }
	
//4- Déclaration de  demmarerServeur
	private void demmarerServeur() {
        try {
            ss = new ServerSocket(PORT);
            s = ss.accept();
            br = new BufferedReader(new InputStreamReader(s.getInputStream()));
            while (true) {
                String cmd;
                cmd = br.readLine();
                execterCommande(cmd);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
//5- Déclaration de  execterCommande
	private void execterCommande(String cmd) {
        System.out.println(cmd);
        String[] t = cmd.split(":");
        if (t.length > 1) {
            int indice = Integer.parseInt(t[0]);
            int val = Integer.parseInt(t[1]);
            tSlider[indice].setValue(val);
        }
    }




