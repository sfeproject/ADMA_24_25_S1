<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../jqm/jquery.mobile-1.4.4.min.css">
<script src="../jqm/jquery-1.11.1.min.js"></script>
<script src="../jqm/jquery.mobile-1.4.4.min.js"></script>
<script>
	function actualiser(){
		var livre = $("#livre option:selected").text();
		var tChamps=livre.split(" - ");
		$("#titre").val(tChamps[1]);
		$("#nbPage").val(tChamps[2]);
	}
	$(document).ready(function() {
		actualiser();
		$("#livre").change(function() {
			actualiser();
		});
	});		
</script>
</head>
<body>
	<?php
		require_once '../db/DB_Functions.php';
	?>
	<div data-role="page" id="index">
			<div data-role="header">
				<h1>Modification</h1>
			</div>
			<div data-role="content">
				<form method="get" action="Modification.php" name="f">
					<label for="livre">Livre</label>
					<select type="text" name="livre" id="livre"/>	
						<?php
							$db = new DB_Functions();
							$db->getLivres();							
						?>
					</select>
					<label for="titre">Titre</label>
					<input type="text" name="titre" id="titre" placeholder="Titre"/>			
					<label for="nbPage">Nb Page</label>
					<input type="text" name="nbPage" id="nbPage" placeholder="Nb Page"/>
					<input type="submit" value="Modifier" />
					<a href="../index.html" class="ui-btn" data-prefetch="true">Retour</a>
				</form>	
			</div>
			<div data-role="footer">
				<h1>Gestion Bibliothèque</h1>
			</div>
	</div>
</body>
</html>