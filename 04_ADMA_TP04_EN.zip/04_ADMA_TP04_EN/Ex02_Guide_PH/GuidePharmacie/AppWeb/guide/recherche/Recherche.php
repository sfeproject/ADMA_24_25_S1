<?php
	


if ( isset($_REQUEST['type'])&& isset($_REQUEST['route'])) {
		$type = $_REQUEST['type'];
		$route = $_REQUEST['route'];
		// include db handler
		require_once '../db/DB_Functions.php';
		$db = new DB_Functions();
		$db->rechercherPharmacie($type,$route);
		
	
	} else {
		$reponse=array();
		$reponse["ETAT"]="ECHEC";
		echo json_encode($reponse);		
	}	
?>	
