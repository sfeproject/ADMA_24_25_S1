create table pharmacie (
		id INTEGER PRIMARY KEY AUTO_INCREMENT,
		nom text NOT NULL,
        type text NOT NULL,
        route text NOT NULL,
		dcv INTEGER
);