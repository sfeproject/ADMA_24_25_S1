package com.guide;

public class Pharmacie {
	private int id;
	private String nom;
	private String type;
	private String route;
	private int dcv;

	public Pharmacie(int id, String nom, String type, String route, int dcv) {
		this.id = id;
		this.nom = nom;
		this.type = type;
		this.route = route;
		this.dcv = dcv;
	}

	public int getId() {
		return id;
	}

	public String getNom() {
		return nom;
	}

	public String getType() {
		return type;
	}

	public String getRoute() {
		return route;
	}

	public int getDcv() {
		return dcv;
	}
	

}
