package com.guide;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {


	  private Button btnAjout;
	  private Button btnRecherche;

	  @Override
	  protected void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.activity_main);
	    init();
	  }

	  private void init() {
	    btnAjout = (Button) findViewById(R.id.btnAjout);
	    btnRecherche = (Button) findViewById(R.id.btnRecherche);
	    ajouterEcouteur();
	  }

	  private void ajouterEcouteur() {
	    btnAjout.setOnClickListener(new OnClickListener() {

	      @Override
	      public void onClick(View v) {
	        ajout();
	      }
	    });
	    btnRecherche.setOnClickListener(new OnClickListener() {

	      @Override
	      public void onClick(View v) {
	    	  recherche();
	      }
	    });
	  }

	 protected void recherche() {
	    Intent i = new Intent(MainActivity.this, Recherche.class);
	    startActivity(i);
	  }

	  protected void ajout() {
	    Intent i = new Intent(MainActivity.this, Ajout.class);
	    startActivity(i);
	  }

}
