<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="../jqm/jquery.mobile-1.4.4.min.css">
<script src="../jqm/jquery-1.11.1.min.js"></script>
<script src="../jqm/jquery.mobile-1.4.4.min.js"></script>
</head>
<body>
<?php
	if (isset($_GET['livre'])) {
		$id = $_GET['livre'];
			 
		// include db handler
		require_once '../db/DB_Functions.php';
		$db = new DB_Functions();
		$db->supprimerLivre($id);
		header('Location: SuppressionForm.php');
		 exit();
	   
	} else {
		header('Location: SuppressionFormError.php');
		 exit();
	}
?>
</body>
</html>