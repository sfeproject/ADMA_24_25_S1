<?php
 
class DB_Functions {
 
    private $db;
 
    //put your code here
    // constructor
    function __construct() {
        require_once 'DB_Connect.php';
        // connecting to database
        $this->db = new DB_Connect();
        $this->db->connect();
    }
 
    // destructor
    function __destruct() {
         
    }
	/**
     * Ajouter Livre
    */
    public function ajouterLivre($titre, $nbPage) {
        $result = mysql_query("INSERT INTO livre(titre, nbPage) VALUES('$titre', $nbPage)")or die(mysql_error());
        // check for successful store
        if ($result) {
            return true;
        } else {
            return false;
        }
		
    }
	/**
     * Supprimer Livre
    */
    public function supprimerLivre($id) {
        $result = mysql_query("DELETE FROM livre WHERE id=$id")or die(mysql_error());
        // check for successful store
        if ($result) {
            return true;
        } else {
            return false;
        }
    }
	/**
     * Modifier Livre
    */
    public function modifierLivre($id,$titre, $nbPage) {
        $result = mysql_query("UPDATE livre SET titre='$titre', nbPage=$nbPage WHERE id=$id")or die(mysql_error());
        // check for successful store
        if ($result) {
            return true;
        } else {
            return false;
        }
    }
   /**
     * Get Livre
    */
    public function getLivres() {
        $result = mysql_query("SELECT * FROM livre;")or die(mysql_error());
        while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
			echo("<option value=".$row['id'].">".$row['id']." - ".$row['titre']." - ".$row['nbpage']."</option>");
		}
		
		mysql_free_result($result);
    }
	
	public function close() {
		$this->db->close();
	}
}
 
?>