create table livre (
	id INTEGER PRIMARY KEY AUTO_INCREMENT,
	titre text NOT NULL,
	nbpage INTEGER
);