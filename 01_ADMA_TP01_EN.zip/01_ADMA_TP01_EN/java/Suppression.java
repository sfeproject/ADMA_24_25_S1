package com.contact;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class Suppression extends AppCompatActivity {
    private Spinner spContact;
    private Button btnSupprimer;
    private Button btnAnnuler;
    private ArrayAdapter<Contact>adpContact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suppression);
        initActivity();
    }

    private void initActivity() {
        spContact=findViewById(R.id.spContact);
        btnSupprimer=findViewById(R.id.btnSupprimer);
        btnAnnuler=findViewById(R.id.btnAnnulerS);
        adpContact=new ArrayAdapter<Contact>(this, android.R.layout.simple_spinner_item);
        spContact.setAdapter(adpContact);
        remplir();
        ajouterEcouteurs();
    }

    private void remplir() {
        
    }

    private void ajouterEcouteurs() {
       
    }

    
}