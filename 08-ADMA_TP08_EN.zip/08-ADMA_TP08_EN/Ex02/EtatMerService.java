package com.mer;



public class EtatMerService   {
    public static final String ACTION_ETAT_MER="ETAT_MER";
   
}
