package com.client.pres;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private Button btnPrec;
    private Button btnSuiv;
    private Button btnPrem;
    private Button btnDer;
    private EditText edNum;
    private Button btnAtt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        btnPrec=findViewById(R.id.btnPrec);
        btnSuiv=findViewById(R.id.btnSuiv);
        btnPrem=findViewById(R.id.btnPrem);
        btnDer=findViewById(R.id.btnDer);
        edNum=findViewById(R.id.edNum);
        btnAtt=findViewById(R.id.btnAtt);
        ajouterEcouteurs();
    }

    private void ajouterEcouteurs() {
    }
}
