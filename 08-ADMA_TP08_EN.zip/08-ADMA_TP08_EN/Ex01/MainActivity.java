package com.analyse;



public class MainActivity extends AppCompatActivity {
    private ImageView imgVisages;
    private Button btnAnalyser;
    private TextView tvNbV;
    private TextView tvNbVS;
    private TextView tvNbYF;
    private TextView tvNbBF;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        imgVisages=(ImageView)findViewById(R.id.imgVisages);
        btnAnalyser=(Button)findViewById(R.id.btnAnalyser);
        tvNbV=(TextView)findViewById(R.id.tvNbV);
        tvNbVS=(TextView)findViewById(R.id.tvNbVS);
        tvNbYF=(TextView)findViewById(R.id.tvNbYF);
        tvNbBF=(TextView)findViewById(R.id.tvNbBF);
        ajouterEcouteur();
    }
    private void ajouterEcouteur() {
        btnAnalyser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                analyser();
            }
        });
    }

    private void analyser() {
        
    }


}
